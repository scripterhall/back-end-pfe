package com.ms.tickethistoireservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketHistoireServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketHistoireServiceApplication.class, args);
	}

}
