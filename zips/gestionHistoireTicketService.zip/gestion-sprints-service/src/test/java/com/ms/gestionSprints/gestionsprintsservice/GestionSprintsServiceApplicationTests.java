package com.ms.gestionSprints.gestionsprintsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionSprintsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
