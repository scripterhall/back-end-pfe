package com.ms.gestionHistoireTicket.gestionHistoireTicketService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionHistoireTicketServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
